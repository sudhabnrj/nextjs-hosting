import React from "react";

export default function ContactPage() {
  return <div>Contact Page</div>;
}
