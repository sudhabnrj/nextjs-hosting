import React from "react";

export default function BlogPage() {
  return <div>Blog Page</div>;
}
